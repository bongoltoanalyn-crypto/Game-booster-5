# Build BOSS BOOSTER APK using GitHub Actions (phone-only)

1. Create a GitHub repository.
2. Upload the *contents* of this project ZIP to the repository root (not the ZIP file itself). Ensure `.github/workflows/build.yml` is included. On mobile, enable “Show hidden files” if needed to confirm `.github` is uploaded.
3. Open the repository's **Actions** tab.
4. Select **Build BOSS BOOSTER APK**, then **Run workflow**. If it does not appear, first commit the workflow to the default branch.
5. Open the completed run. Under **Artifacts**, download `BOSS-BOOSTER-debug-APK` and extract the downloaded artifact ZIP to get the `.apk`.

A failed build means the source needs fixing; inspect the failed step's logs. This workflow builds a debug APK, not a release-signed APK. The project is not guaranteed to compile or to implement hardware overclocking or live in-game voice changing.
